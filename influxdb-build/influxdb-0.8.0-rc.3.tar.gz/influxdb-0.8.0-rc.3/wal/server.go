package wal

type Server interface {
	GetId() uint32
}
