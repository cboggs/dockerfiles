package wal

type Shard interface {
	Id() uint32
}
